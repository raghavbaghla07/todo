import React from "react";

const TodoTable = ({ todos, deleteTodo, setId }) => {
  return (
    <div className=" d-flex justify-content-center mt-5 w-full ">
      <div>
        <table className="table table-dark table-hover text-center">
          <thead>
            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {todos.map((todo) => (
              <tr key={todo.id}>
                <td>{todo.title}</td>
                <td>{todo.description}</td>
                <td>
                  <button
                    onClick={() => setId(todo.id)}
                    className="btn btn-warning mx-2"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => deleteTodo(todo.id)}
                    className="btn btn-danger"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TodoTable;
